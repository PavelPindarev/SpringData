package com.example.springdataintroexercise.models;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
