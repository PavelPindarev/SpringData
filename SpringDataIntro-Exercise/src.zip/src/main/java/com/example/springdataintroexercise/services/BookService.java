package com.example.springdataintroexercise.services;

import org.springframework.stereotype.Service;

@Service
public class BookService {

    public void insert() {

    }

}
