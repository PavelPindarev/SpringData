package com.example.springdataintroexercise.models;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
