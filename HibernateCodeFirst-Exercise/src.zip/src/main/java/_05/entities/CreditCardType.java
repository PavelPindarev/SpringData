package _05.entities;

public enum CreditCardType {
    BlueBush, MasterCard, VISA, DiscoverIt, Wells
}
